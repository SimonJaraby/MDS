package cz.vutbr.feec.utko.bpcmds.projekt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjektApplicationTests {

	@Test
	void contextLoads() {
	}

}
